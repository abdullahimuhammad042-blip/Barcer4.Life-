package com.barcer4life.app;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.libraries.ads.mobile.sdk.MobileAds;

public class MainActivity extends AppCompatActivity {
    LinearLayout content;
    int blue = Color.rgb(11,31,94), maroon = Color.rgb(142,21,56), gold = Color.rgb(245,196,0);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        MobileAds.initialize(this);
        buildUI();
    }

    TextView tv(String text, float size, int color) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(color);
        v.setPadding(18,14,18,14); return v;
    }

    void buildUI() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,246,250));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(12,8,12,8); header.setBackgroundColor(blue);
        ImageView logo = new ImageView(this); logo.setImageResource(com.barcer4life.app.R.drawable.barcer_logo); logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo, new LinearLayout.LayoutParams(58,58));
        TextView title = tv("BARCER 4 LIFE", 21, Color.WHITE); title.setTypeface(null, 1); header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,12,12,12);
        ScrollView scroll = new ScrollView(this); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.WHITE);
        String[] tabs = {"Home","News","Transfers","Matches","Photos"};
        for(String s: tabs){ Button bt = new Button(this); bt.setText(s); bt.setTextSize(11); bt.setOnClickListener(v -> showSection(s)); nav.addView(bt,new LinearLayout.LayoutParams(0,60,1)); }
        root.addView(nav);
        setContentView(root); showSection("Home");
    }

    void showSection(String section){
        content.removeAllViews();
        TextView h = tv(section.equals("Home") ? "Visca el Barça! 🔴🔵" : section, 25, blue); h.setTypeface(null,1); content.addView(h);
        if(section.equals("Home")){
            card("📰 Latest Barça News", "Your Barcelona news feed will appear here. Add your news source/API in the next version.");
            card("🔥 Transfer News", "Transfer updates, rumours and confirmed deals.");
            card("⚽ Matches", "Upcoming fixtures and match results.");
            card("🏆 Trophies", "Barcelona trophy and season history.");
            card("📸 Photos", "Barcelona photos and fan content.");
            TextView ad = tv("ADVERTISEMENT\nAdMob placement — connect your real AdMob ID before release.", 13, Color.DKGRAY); ad.setGravity(Gravity.CENTER); ad.setBackgroundColor(Color.WHITE); content.addView(ad);
        } else {
            card(section, "This section is ready. In the next build, we can connect live content and notifications.");
        }
    }

    void card(String title, String body){
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(16,8,16,8); box.setBackgroundColor(Color.WHITE);
        TextView t=tv(title,18,maroon); t.setTypeface(null,1); box.addView(t); box.addView(tv(body,14,Color.DKGRAY));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,12); content.addView(box,p);
    }
}
