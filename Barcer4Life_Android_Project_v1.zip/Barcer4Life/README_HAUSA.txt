BARCER 4 LIFE — Android App (Version 1.0)

Abin da aka fara:
- Home
- News
- Transfers
- Matches
- Photos
- Trophies section placeholder
- Logo na Barcer 4 Life
- AdMob SDK an saka a project, amma dole a maye gurbin AdMob App ID da naka kafin production.

Muhimmi:
Wannan source project ne na Android Studio; ba APK da aka riga aka compile ba. Wannan environment din ba shi da Android build toolchain, saboda haka ba zan yi ikirarin cewa an samar da APK ba.

Mataki na gaba:
1. Bude project din a Android Studio.
2. Sync Gradle.
3. Create/register app a AdMob, sannan ka saka real App ID a app/src/main/res/values/strings.xml.
4. Saka real news/API ko backend domin labarai su rika zuwa kai tsaye.
5. Build APK/AAB, test, sannan a shirya Google Play release.
