package com.barcer4life.app;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.libraries.ads.mobile.sdk.MobileAds;

public class MainActivity extends AppCompatActivity {
    LinearLayout content;
    int blue = Color.rgb(11,31,94), maroon = Color.rgb(142,21,56), gold = Color.rgb(245,196,0);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        MobileAds.initialize(this);
        buildUI();
    }

    TextView tv(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        v.setPadding(16,12,16,12); return v;
    }

    void buildUI() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,246,250));

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(10,7,10,7); header.setBackgroundColor(blue);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.barcer_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo, new LinearLayout.LayoutParams(56,56));
        TextView title = tv("BARCER 4 LIFE", 20, Color.WHITE); title.setTypeface(null,1);
        header.addView(title, new LinearLayout.LayoutParams(0,-2,1));
        TextView live = tv("● LIVE", 12, gold); live.setTypeface(null,1); header.addView(live);
        root.addView(header);

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,12,12,12);
        ScrollView scroll = new ScrollView(this); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.WHITE);
        String[] tabs = {"Home","News","Transfers","Matches","Trophies","Photos"};
        for(String s: tabs){
            Button bt = new Button(this); bt.setText(s); bt.setTextSize(10); bt.setAllCaps(false);
            bt.setOnClickListener(v -> showSection(s));
            nav.addView(bt,new LinearLayout.LayoutParams(0,64,1));
        }
        root.addView(nav);
        setContentView(root); showSection("Home");
    }

    void showSection(String section){
        content.removeAllViews();
        TextView h = tv(section.equals("Home") ? "Visca el Barça! 🔴🔵" : section, 24, blue);
        h.setTypeface(null,1); content.addView(h);

        if(section.equals("Home")) {
            card("📰 One win away from best ever start to LaLiga",
                    "Barça will host Getafe after the international break with a chance to equal the club's 2013/14 best start.",
                    "https://www.fcbarcelona.com/en/news");
            card("⭐ Four Barça nominees for LaLiga September awards",
                    "Raphinha, Hansi Flick, Pau Cubarsí and João Cancelo were nominated for different September awards.",
                    "https://www.fcbarcelona.com/en/football/first-team/news/4580732/four-barca-players-nominated-for-laligas-september-awards");
            card("🏆 Barça handball reach World Championship final",
                    "Barça beat Zamalek 39-29 and secured a place in the grand final.",
                    "https://www.fcbarcelona.com/en/handball/first-team/news/4582491/barca-39-29-zamalek-world-finalists");
            adCard();
        } else if(section.equals("News")) {
            card("Latest official Barça news", "Open the official FC Barcelona news feed for the newest stories across the club.", "https://www.fcbarcelona.com/en/news");
            card("2026/27 squad numbers confirmed", "The club has confirmed the first-team shirt numbers for the 2026/27 season.", "https://www.fcbarcelona.com/en/news/4570894/202627-first-team-jersey-numbers-confirmed");
            card("International schedule", "Official schedule for Barça players representing their national teams.", "https://www.fcbarcelona.com/en/football/first-team/news/4579417/international-schedule-for-fc-barcelona-players");
            adCard();
        } else if(section.equals("Transfers")) {
            card("Transfer Centre", "The 2026/27 transfer window is closed. This section is ready for confirmed deals and clearly labelled rumours in future updates.", "https://www.fcbarcelona.com/en/news");
            card("Squad update", "The official club page confirms that the first-team squad is set after the transfer window closed.", "https://www.fcbarcelona.com/en/news/4570894/202627-first-team-jersey-numbers-confirmed");
            adCard();
        } else if(section.equals("Matches")) {
            card("Next Barça men’s match", "The official Barça news feed currently lists the upcoming Getafe fixture after the international break.", "https://www.fcbarcelona.com/en/news");
            card("LaLiga Clásico", "The LaLiga Clásico at Spotify Camp Nou is scheduled for 25 October 2026, kick-off 9:00pm CEST.", "https://www.fcbarcelona.com/en/news");
            adCard();
        } else if(section.equals("Trophies")) {
            card("🏆 Barça honours", "A dedicated trophy-history section is included in the app. More season-by-season details can be added in the next build.", "https://www.fcbarcelona.com/en/club/history");
            adCard();
        } else if(section.equals("Photos")) {
            card("📸 Latest galleries", "Open the official Barça galleries for recent match and team photos.", "https://www.fcbarcelona.com/en/news");
            adCard();
        }
    }

    void card(String title, String body, String url){
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(8,6,8,8); box.setBackgroundColor(Color.WHITE);
        TextView t=tv(title,18,maroon); t.setTypeface(null,1); box.addView(t);
        box.addView(tv(body,14,Color.DKGRAY));
        Button read = new Button(this); read.setText("Read official source"); read.setAllCaps(false);
        read.setTextColor(blue); read.setOnClickListener(v -> openUrl(url)); box.addView(read);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,12); content.addView(box,p);
    }

    void adCard(){
        TextView ad = tv("ADVERTISEMENT\nAdMob placement — connect your real AdMob App ID and Ad Unit ID before publishing.", 12, Color.DKGRAY);
        ad.setGravity(Gravity.CENTER); ad.setBackgroundColor(Color.WHITE); content.addView(ad);
    }

    void openUrl(String url){
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception ignored) {}
    }
}
