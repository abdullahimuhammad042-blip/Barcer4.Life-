BARCER 4 LIFE — Android Project v2

An fara gina app din Barcelona/football mai sauki ga masu amfani.

Abubuwan da ke ciki:
- Home
- News
- Transfers
- Matches
- Trophies
- Photos
- Official source links
- AdMob placement placeholder
- Logo na Barcer 4 Life

Muhimmi:
1. Wannan source project ne; ba APK ba.
2. Kafin Google Play release, a saka real AdMob App ID da Ad Unit IDs.
3. A duba/gyara bayanan labarai akai-akai; links na yanzu suna zuwa official FC Barcelona website.
4. Kada a yi amfani da hotuna ko alamar FC Barcelona ta hanyar da ta karya copyright/trademark rules.
